﻿using ClassLibrary2.BL;
using ClassLibrary2.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppProject
{
    public partial class Sider : Form
    {
        public Sider()
        {
            InitializeComponent();
        }
        private void LoadDataIntoGrid()
        {
            List<ProductBL> productList = ProductDL.GetAllSiders();

            // Clear existing columns in DataGridView (if any)
            dataGridView1.Columns.Clear();

            // Manually add columns to the DataGridView
            dataGridView1.Columns.Add("Name", "Name");
            dataGridView1.Columns.Add("Price", "Price");
            dataGridView1.Columns.Add("Category", "Category");

            // Bind data to the DataGridView
            foreach (ProductBL product in productList)
            {
                dataGridView1.Rows.Add(product.GetName(), product.GetPrice(), product.GetCatagory());
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Product_Catagories product_Catagories = new Product_Catagories();
            product_Catagories.Show();
        }

        private void Sider_Load(object sender, EventArgs e)
        {
            LoadDataIntoGrid();
            dataGridView1.Refresh();
        }
    }
}
