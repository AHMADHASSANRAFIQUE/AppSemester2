﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary2.BL;
using ClassLibrary2.DL;
using ClassLibrary2.Utils;

namespace AppProject
{
    public partial class Add_Product : Form
    {
        public Add_Product()
        {            
            InitializeComponent();
        }        
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            float currentDiscount = ProductDL.GetCurrentDiscountFromDatabase(textBox1.Text);
            if (!int.TryParse(textBox4.Text, out int discountValue))
            {
                MessageBox.Show("Please enter a valid discount value (numeric).", "Invalid Discount", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox4.Text = ""; // Clear the textbox
            }
            else if (discountValue < 0 || discountValue > 100)
            {
                MessageBox.Show("Discount value must be between 0 and 100.", "Invalid Discount", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox4.Text = ""; // Clear the textbox
            }
            else
            {
                float totalDiscount = currentDiscount + discountValue;
                if (totalDiscount < 0 || totalDiscount > 100)
                {
                    MessageBox.Show("The sum of current discount and new discount must be between 0 and 100.", "Invalid Discount Sum", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBox4.Text = ""; // Clear the textbox
                }
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminMenu adminMenu = new AdminMenu();
            adminMenu.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            float currentDiscount = ProductDL.GetCurrentDiscountFromDatabase(textBox1.Text);
            currentDiscount += float.Parse(textBox4.Text);
            ProductBL data = new ProductBL(textBox1.Text, float.Parse(textBox2.Text), int.Parse(textBox3.Text), currentDiscount, comboBox1.Text);
            bool result = ProductDL.Add(data);
            if (result)
            {
                MessageBox.Show("Product Successfully Added!!");
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }
    }
}
