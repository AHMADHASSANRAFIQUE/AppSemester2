﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ClassLibrary2.BL;
using ClassLibrary2.DL;
using ClassLibrary2.Utils;

namespace AppProject
{
    public partial class RemoveProduct : Form
    {
        public RemoveProduct()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminMenu adminMenu = new AdminMenu();
            adminMenu.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {            
            bool result = ProductDL.Delete(textBox1.Text);
            if (result)
            {
                MessageBox.Show("Product Successfully Deleted!!");
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }
    }
}
