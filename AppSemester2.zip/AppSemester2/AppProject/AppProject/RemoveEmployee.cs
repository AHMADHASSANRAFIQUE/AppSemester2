﻿using ClassLibrary2.BL;
using ClassLibrary2.DL;
using ClassLibrary2.Utils;
using ClassLibrary2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AppProject
{
    public partial class RemoveEmployee : Form
    {
        public RemoveEmployee()
        {
            InitializeComponent();
        }
        public static bool ValidatePassword(string password)
        {
            // Check if password is not null and exactly 4 characters long
            if (string.IsNullOrEmpty(password) || password.Length != 4)
            {
                return false;
            }

            foreach (char c in password)
            {
                if (!char.IsDigit(c))
                {
                    // Password contains a non-digit character
                    return false;
                }
            }

            // Password is exactly 4 characters long and contains only digits
            return true;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            CrrendentialBL data = new CrrendentialBL(textBox1.Text, textBox2.Text, "Employee");
            bool result = ObjectHandler.GetUserDB().DeleteStudentByRoll(data.GetName());
            if (result)
            {
                MessageBox.Show("Successfully Deleted");
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Password_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void UsrName_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminMenu adminMenu = new AdminMenu();
            adminMenu.Show();
        }
    }
}
