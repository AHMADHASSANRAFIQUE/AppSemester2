﻿using ClassLibrary2.BL;
using ClassLibrary2.DL;
using ClassLibrary2.Utils;
using ClassLibrary2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AppProject
{
    public partial class SignIn : Form
    {
        public SignIn()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CrrendentialBL data = new CrrendentialBL(textBox1.Text, textBox2.Text);
            string result = ObjectHandler.GetUserDB().Check(data);
            if (result != null)
            {
                MessageBox.Show("Successfully Signed In :)");
                if (result == "Admin")
                {
                    this.Hide();
                    AdminMenu form = new AdminMenu(data);
                    form.Show();
                }
                else if (result == "Customer")
                {
                    this.Hide();
                    Customer_Menu form = new Customer_Menu(data);
                    form.Show();
                }
                else if (result == "Employee")
                {
                    this.Hide();
                    EmployeeMenu form = new EmployeeMenu();
                    form.Show();
                }
            }
            else
            {
                MessageBox.Show("Error!");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }
    }
}
