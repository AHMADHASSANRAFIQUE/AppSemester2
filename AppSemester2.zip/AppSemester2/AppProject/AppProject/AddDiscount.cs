﻿using ClassLibrary2.BL;
using ClassLibrary2.DL;
using ClassLibrary2.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AppProject
{
    public partial class AddDiscount : Form
    {
        public AddDiscount()
        {
            InitializeComponent();
            AddItems3();
        }

        private void AddDiscount_Load(object sender, EventArgs e)
        {

        }
        private void AddItems3()
        {
            string query = "SELECT Name FROM ProductData";
            
            string connectionString = Utility.GetConnectionString();
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

            SqlCommand command = new SqlCommand(query, con);

            SqlDataReader reader = command.ExecuteReader();
            comboBox1.Items.Clear();

            while (reader.Read())
            {
                comboBox1.Items.Add(reader.GetString(0));
            }

            reader.Close();
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeMenu employeeMenu = new EmployeeMenu();
            employeeMenu.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            float currentDiscount = ProductDL.GetCurrentDiscountFromDatabase(comboBox1.Text);
            currentDiscount += float.Parse(textBox2.Text);
            bool result = ProductDL.UpdateDiscount(comboBox1.Text, currentDiscount);
            if (result)
            {
                MessageBox.Show("Discount Successfully Added!!");
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            float currentDiscount = ProductDL.GetCurrentDiscountFromDatabase(comboBox1.Text);
            if (textBox2.Text != "")
            {
                MessageBox.Show("Previous Discount is: " + currentDiscount + "%");
            }
            if (!int.TryParse(textBox2.Text, out int discountValue))
            {
                MessageBox.Show("Please enter a valid discount value (numeric).", "Invalid Discount", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Text = ""; // Clear the textbox
            }
            else if (discountValue < 0 || discountValue > 100)
            {
                MessageBox.Show("Discount value must be between 0 and 100.", "Invalid Discount", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Text = ""; // Clear the textbox
            }
            else
            {
                float totalDiscount = currentDiscount + discountValue;
                if (totalDiscount < 0 || totalDiscount > 100)
                {
                    MessageBox.Show("The sum of current discount and new discount must be between 0 and 100.", "Invalid Discount Sum", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBox2.Text = ""; // Clear the textbox
                }
            }
        }
    }
}
