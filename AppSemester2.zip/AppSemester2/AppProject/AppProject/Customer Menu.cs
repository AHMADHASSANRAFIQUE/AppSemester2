﻿using ClassLibrary2.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppProject
{
    public partial class Customer_Menu : Form
    {
        private CrrendentialBL user;
        public Customer_Menu()
        {
            InitializeComponent();
        }
        public Customer_Menu(CrrendentialBL user)
        {
            InitializeComponent();
            this.user = user;
        }
        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();
            ChangePasswordC changePasswordC = new ChangePasswordC();
            changePasswordC.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Product_Catagories product_Catagories = new Product_Catagories(user);
            product_Catagories.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddFeedBack addFeedBack = new AddFeedBack();
            addFeedBack.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddRating addRating = new AddRating();
            addRating.Show();
        }
    }
}
