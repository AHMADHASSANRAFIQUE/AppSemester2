﻿using ClassLibrary2.BL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppProject
{
    public partial class AdminMenu : Form
    {
        private CrrendentialBL user;
        string name;
        public AdminMenu(CrrendentialBL user)
        {
            InitializeComponent();
            this.user = user;
            this.name = user.GetName();
            label2.Text = "Hi! " +user.GetName();
            InitializeLabel();
        }
        private void InitializeLabel()
        {
            if (user != null)
            {
                label2.Text = "Hi! " + user.GetName();
            }
            else 
            {
                label2.Text = "Hi! " + name;
            }
        }
        public AdminMenu()
        {
            InitializeComponent();           
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Add_Employees add_Employees = new Add_Employees();
            add_Employees.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            RemoveEmployee removeEmployee = new RemoveEmployee();
            removeEmployee.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            ChangePassword changePassword = new ChangePassword(user);
            changePassword.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Add_Product products = new Add_Product();
            products.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            UpdateProduct mainForm = new UpdateProduct();
            mainForm.UpdateLastVisitedForm("AdminForm");
            mainForm.Show();
            this.Hide();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            ViewProducts mainForm = new ViewProducts();
            mainForm.UpdateLastVisitedForm("AdminForm");
            mainForm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ViewStock mainForm = new ViewStock();
            mainForm.UpdateLastVisitedForm("AdminForm");
            mainForm.Show();
            this.Hide();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();
            RemoveProduct removeProduct = new RemoveProduct();
            removeProduct.Show();
        }

        private void AdminMenu_Load(object sender, EventArgs e)
        {
            InitializeLabel();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            ViewComplains viewComplains = new ViewComplains();
            viewComplains.UpdateLastVisitedForm("AdminForm");
            viewComplains.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            ViewRating viewRating = new ViewRating();
            viewRating.UpdateLastVisitedForm("AdminForm");
            viewRating.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            ViewFeedBack viewFeedBack = new ViewFeedBack();
            viewFeedBack.UpdateLastVisitedForm("AdminForm");
            viewFeedBack.Show();
        }
    }
}
