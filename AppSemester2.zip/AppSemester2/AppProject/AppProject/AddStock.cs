﻿using ClassLibrary2.BL;
using ClassLibrary2.DL;
using ClassLibrary2.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AppProject
{
    public partial class AddStock : Form
    {
        public AddStock()
        {
            InitializeComponent();
            AddItems3();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeMenu employeeMenu = new EmployeeMenu();
            employeeMenu.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int currentDiscount = ProductDL.GetCurrentStockFromDatabase(comboBox1.Text);
            currentDiscount += int.Parse(textBox2.Text);
            bool result = ProductDL.UpdateStock(comboBox1.Text, currentDiscount);
            if (result)
            {
                MessageBox.Show("Stock Successfully Added!!");
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox2.Text, out int discountValue))
            {
                MessageBox.Show("Please enter a valid Stock value (numeric).", "Invalid Stock", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Text = ""; // Clear the textbox
            }
            else if (discountValue < 0 || discountValue > 100)
            {
                MessageBox.Show("Stock value must be between 0 and 100.", "Invalid Stock", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Text = ""; // Clear the textbox
            }            
        }
        private void AddItems3()
        {
            string query = "SELECT Name FROM ProductData";

            string connectionString = Utility.GetConnectionString();
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();

            SqlCommand command = new SqlCommand(query, con);

            SqlDataReader reader = command.ExecuteReader();
            comboBox1.Items.Clear();

            while (reader.Read())
            {
                comboBox1.Items.Add(reader.GetString(0));
            }

            reader.Close();
            con.Close();
        }

    }
}
