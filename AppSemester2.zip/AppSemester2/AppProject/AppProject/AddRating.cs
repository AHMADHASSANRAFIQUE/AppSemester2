﻿using ClassLibrary2.BL;
using ClassLibrary2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary2.DL;

namespace AppProject
{
    public partial class AddRating : Form
    {
        public AddRating()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customer_Menu customer_Menu = new Customer_Menu();
            customer_Menu.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReviewBL reviewBL = new ReviewBL("Null", textBox1.Text, comboBox1.Text, "Null");
            bool result = ReviewsDL.AddRating(reviewBL);
            if(result)
            {
                MessageBox.Show("Add Successfully");
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }
    }
}
