﻿using ClassLibrary2.BL;
using ClassLibrary2.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AppProject
{
    public partial class AddComplains : Form
    {
        public AddComplains()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeMenu employeeMenu = new EmployeeMenu();
            employeeMenu.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReviewBL reviewBL = new ReviewBL("Null", textBox1.Text, "Null", textBox2.Text);
            bool result = ReviewsDL.AddComplain(reviewBL);
            if (result)
            {
                MessageBox.Show("Add Successfully");
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }
    }
}
