﻿using ClassLibrary2.BL;
using ClassLibrary2.DL;
using ClassLibrary2.Utils;
using ClassLibrary2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppProject
{
    public partial class ChangePasswordE : Form
    {
        public ChangePasswordE()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            EmployeeMenu employeeMenu = new EmployeeMenu();
            employeeMenu.Show();
        }
        public static bool ValidatePassword(string password)
        {
            // Check if password is not null and exactly 4 characters long
            if (string.IsNullOrEmpty(password) || password.Length != 4)
            {
                return false;
            }

            foreach (char c in password)
            {
                if (!char.IsDigit(c))
                {
                    // Password contains a non-digit character
                    return false;
                }
            }

            // Password is exactly 4 characters long and contains only digits
            return true;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (ValidatePassword(textBox2.Text))
            {
                CrrendentialBL data = new CrrendentialBL(textBox1.Text, textBox2.Text, "Employee");
                bool result = ObjectHandler.GetUserDB().Update(data);
                if (result)
                {
                    MessageBox.Show("Successfully Updated");
                }
                else
                {
                    MessageBox.Show("Error!");
                }
            }
            else
            {
                MessageBox.Show("Password Must be 4 digits");
            }
        }
    }
}
