﻿using ClassLibrary2.BL;
using ClassLibrary2.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppProject
{
    public partial class ViewRating : Form
    {
        public ViewRating()
        {
            InitializeComponent();
        }
        string lastVisitedFormName = "";
        private void LoadDataIntoGrid()
        {
            List<ReviewBL> reviewList = ReviewsDL.GetAllReviews();

            // Clear existing columns in DataGridView (if any)
            dataGridView1.Columns.Clear();

            // Manually add columns to the DataGridView
            dataGridView1.Columns.Add("UserName", "UserName");
            dataGridView1.Columns.Add("Rating", "Rating");

            // Bind data to the DataGridView
            foreach (ReviewBL product in reviewList)
            {
                dataGridView1.Rows.Add(product.GetUserName(), product.GetRating());
            }
        }
        public void UpdateLastVisitedForm(string formName)
        {
            lastVisitedFormName = formName;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (lastVisitedFormName == "AdminForm")
            {
                AdminMenu adminForm = new AdminMenu();
                adminForm.Show();
                this.Hide(); // Hide the current form (MainForm)
            }
            else if (lastVisitedFormName == "EmployeeForm")
            {
                EmployeeMenu employeeForm = new EmployeeMenu();
                employeeForm.Show();
                this.Hide(); // Hide the current form (MainForm)
            }
        }

        private void ViewRating_Load(object sender, EventArgs e)
        {
            LoadDataIntoGrid();
            dataGridView1.Refresh();
        }
    }
}
