﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary2.BL;
using ClassLibrary2.DL;
using ClassLibrary2.Utils;
using ClassLibrary2;

namespace AppProject
{
    public partial class Product_Catagories : Form
    {
        private List<string> carts = new List<string>();
        private CrrendentialBL user;
        public Product_Catagories()
        {
            InitializeComponent();
        }
        public Product_Catagories(CrrendentialBL user)
        {
            InitializeComponent();
            this.user = user;
        }
        public Product_Catagories(List<string> cart, CrrendentialBL user)
        {
            InitializeComponent();
            carts.AddRange(cart);
        }
        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customer_Menu customer_Menu = new Customer_Menu(user);
            customer_Menu.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            CrispyItems crispyItems = new CrispyItems();
            crispyItems.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();
            FastFood fastFood = new FastFood();
            fastFood.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Beverages beverages = new Beverages();
            beverages.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Sider sider = new Sider();
            sider.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            ToOrder toOrder = new ToOrder(carts, user);
            toOrder.Show();
        }
    }
}
