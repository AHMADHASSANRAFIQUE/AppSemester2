﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppProject
{
    public partial class EmployeeMenu : Form
    {
        public EmployeeMenu()
        {
            InitializeComponent();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            ChangePasswordE changePasswordE = new ChangePasswordE();
            changePasswordE.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddProductE add_Product = new AddProductE();
            add_Product.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            UpdateProduct mainForm = new UpdateProduct();
            mainForm.UpdateLastVisitedForm("EmployeeForm");
            mainForm.Show();
            this.Hide();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            ViewProducts mainForm = new ViewProducts();
            mainForm.UpdateLastVisitedForm("EmployeeForm");
            mainForm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ViewStock mainForm = new ViewStock();
            mainForm.UpdateLastVisitedForm("EmployeeForm");
            mainForm.Show();
            this.Hide();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddStock addStock = new AddStock();
            addStock.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddDiscount addDiscount = new AddDiscount();
            addDiscount.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();
            RemoveDiscount removeDiscount = new RemoveDiscount();
            removeDiscount.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddComplains addComplains = new AddComplains();
            addComplains.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ViewFeedBack mainForm = new ViewFeedBack();
            mainForm.UpdateLastVisitedForm("EmployeeForm");
            mainForm.Show();
            this.Hide();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            ViewRating viewRating = new ViewRating();
            viewRating.UpdateLastVisitedForm("EmployeeForm");
            viewRating.Show();
        }
    }
}
