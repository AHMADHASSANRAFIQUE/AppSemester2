﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary2.BL;
using ClassLibrary2.DL;
using ClassLibrary2.Utils;
using ClassLibrary2.Interface;
using ClassLibrary2;

namespace AppProject
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }        
        public static bool ValidatePassword(string password)
        {
            // Check if password is not null and exactly 4 characters long
            if (string.IsNullOrEmpty(password) || password.Length != 4)
            {
                return false;
            }

            foreach (char c in password)
            {
                if (!char.IsDigit(c))
                {
                    // Password contains a non-digit character
                    return false;
                }
            }

            // Password is exactly 4 characters long and contains only digits
            return true;
        }

        private void button4_Click(object sender, EventArgs e)
        {            
            CrrendentialBL data = new CrrendentialBL(textBox1.Text, textBox2.Text, comboBox1.Text);
            bool result = ObjectHandler.GetUserDB().DeleteStudentByRoll(data.GetName());
            if (result)
            {
                MessageBox.Show("Successfully Deleted");
            }
            else
            {
                MessageBox.Show("Error!");
            }                        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ValidatePassword(textBox2.Text))
            {                
                CrrendentialBL data = new CustomerBL(textBox1.Text, textBox2.Text, comboBox1.Text,textBox3.Text);
                bool result = ObjectHandler.GetUserDB().Add(data);
                if (result)
                {
                    MessageBox.Show("Successfully SignUp");
                }
                else
                {
                    MessageBox.Show("Error!");
                }
            }
            else
            {
                MessageBox.Show("Password Must be 4 digits");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (ValidatePassword(textBox2.Text))
            {
                CrrendentialBL data = new CrrendentialBL(textBox1.Text, textBox2.Text, comboBox1.Text);
                bool result = ObjectHandler.GetUserDB().Update(data);
                if (result)
                {
                    MessageBox.Show("Successfully Updated");
                }
                else
                {
                    MessageBox.Show("Error!");
                }
            }
            else
            {
                MessageBox.Show("Password Must be 4 digits");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }
    }
}
