﻿using ClassLibrary2.BL;
using ClassLibrary2.DL;
using ClassLibrary2.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppProject
{
    public partial class ToOrder : Form
    {
        List<string> strings;
        private CrrendentialBL user;
        public ToOrder(List<string> productlist, CrrendentialBL user)
        {
            InitializeComponent();
            strings = productlist;
            this.user = user;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Product_Catagories product_Catagories = new Product_Catagories();
            product_Catagories.Show();
        }
        private void add()
        {
            string connString = Utility.GetConnectionString();

            try
            {
                // Create a connection to the database
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    // Open the connection
                    conn.Open();

                    // Create a parameterized SQL query with the product names
                    string sqlQuery = $"SELECT Name, Price, Discount FROM ProductData WHERE Name IN ({string.Join(",", strings.Select(p => $"'{p}'"))})";

                    // Create a command to execute the query
                    using (SqlCommand cmd = new SqlCommand(sqlQuery, conn))
                    {
                        // Create a DataAdapter to fill a DataTable
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            // Create a DataTable to hold the retrieved data
                            DataTable dt = new DataTable();

                            // Fill the DataTable with the data from the database
                            adapter.Fill(dt);

                            // Bind the DataTable to your DataGridView
                            dataGridView1.DataSource = dt;
                        }
                    }
                }
            }
            catch
            {
                // Handle the exception (e.g., display an error message)
                MessageBox.Show($"First Add Products in Cart!! ");
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //string username = user.GetName();
            int res = OrderDL.InsertData(strings);
            if (res != 0)
            {
                MessageBox.Show("Total Price is: " + res);
                MessageBox.Show("ThankYou!");
                this.Hide();
                Customer_Menu customer_Menu = new Customer_Menu();
                customer_Menu.Show();
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {            
            if (e.ColumnIndex == dataGridView1.Columns["Price"].Index && e.RowIndex >= 0)
            {
                // Get the price and discount values from the current row
                decimal price = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells["Price"].Value);
                int discount = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["Discount"].Value);

                // Calculate the discounted price
                decimal discountedPrice = price - (price * discount / 100);

                // Set the formatted value to display the discounted price
                //e.Value = discountedPrice.ToString("C");
            }
        }

        private void ToOrder_Load(object sender, EventArgs e)
        {
            add();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                string productName = Convert.ToString(selectedRow.Cells["Name"].Value);
                decimal productPrice = Convert.ToDecimal(selectedRow.Cells["Price"].Value);
                dataGridView1.Rows.Remove(selectedRow); // Remove the selected row from the grid
                strings.Remove(productName); // Assuming 'strings' is a collection where you want to remove the productName
                MessageBox.Show("Product Successfully Remove from Cart!!");
            }

        }
    }
}
