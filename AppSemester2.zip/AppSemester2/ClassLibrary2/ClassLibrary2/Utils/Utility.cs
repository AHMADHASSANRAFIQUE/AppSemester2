﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2.Utils
{
    public class Utility
    {
        private static string ConnectionString = "Data Source=DESKTOP-QI6H2EA;Initial Catalog=Signup;Integrated Security=True;Encrypt=False;Trusted_Connection=True";

        public static string GetConnectionString()
        {
            return ConnectionString;
        }
    }
}
