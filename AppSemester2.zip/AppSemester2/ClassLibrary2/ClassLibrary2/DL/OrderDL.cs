﻿using ClassLibrary2.Utils;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2.DL
{
    public class OrderDL
    {
        public static decimal Check(List<string> strings)
        {
            decimal totalPrice = 0;

            // Assuming connectionString is your SQL Server connection string
            string connectionString = Utility.GetConnectionString();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Constructing the parameterized SQL query
                foreach (string productName in strings)
                {
                    string query = "SELECT Price, Discount FROM ProductData WHERE Name = @ProductName";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ProductName", productName);

                    // Open the connection before executing the command
                    connection.Open();

                    // Execute the command and get the result
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Assuming Price and Discount columns are of type decimal in the database
                        decimal price = Convert.ToDecimal(reader["Price"]);
                        int discount = Convert.ToInt32(reader["Discount"]);

                        // Calculate the discounted price
                        decimal discountedPrice = price - (price * discount / 100);
                        totalPrice += discountedPrice;
                    }
                    else
                    {
                        // Handle cases where the product name is not found
                        // You can throw an exception or log a message here
                    }

                    // Close the reader and connection after each iteration
                    reader.Close();
                    connection.Close();
                }
            }
            return totalPrice;
        }





        public static int InsertData(List<string> productNames)
        {
            //try
            //{
            decimal totalPrice = 0;
            using (SqlConnection connection = new SqlConnection(Utility.GetConnectionString()))
            {
                connection.Open();
                string productNameList = string.Join(", ", productNames); // Concatenate the product names

                string query = "INSERT INTO [Order] (TotalPrice, ProductName) VALUES (@TotalPrice, @ProductNameList)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@TotalPrice", Check(productNames));
                    command.Parameters.AddWithValue("@ProductNameList", productNameList);
                    command.ExecuteNonQuery();
                    totalPrice = Check(productNames);
                }
                return (int)totalPrice;
            }

            //}
            //catch
            //{
            //return false;
            //}
        }

    }
}
