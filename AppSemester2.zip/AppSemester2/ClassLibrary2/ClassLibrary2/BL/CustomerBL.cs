﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2.BL
{
    public class CustomerBL : CrrendentialBL
    {
        private string Address;
        public CustomerBL(string name, string pass, string role, string Address) : base(name, pass, role)
        {
            this.Address = Address;
        }

        public string GetAddress()
        {
            return this.Address;
        }
    }

}
