﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2.BL
{
    public class OrderBL
    {
        private string TotalPrice;
        private string UserName;
        private List<string> cart = new List<string>();
        public OrderBL(string totalPrice, string userName, List<string> list)
        {
            this.TotalPrice = totalPrice;
            this.UserName = userName;
            this.cart = list;
        }
        public string GetTPrice() 
        {
            return this.TotalPrice;
        }
        public string GetUserName()
        {
            return UserName;
        }
        public List<string> GetCart()
        {
            return cart;
        }
    }    
}
