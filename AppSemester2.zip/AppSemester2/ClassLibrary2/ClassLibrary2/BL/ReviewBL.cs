﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2.BL
{
    public class ReviewBL
    {
        private string UserName;
        private string FeedBack;
        private string Rating;
        private string Complains;
        public ReviewBL(string feedBack, string UserName, string rating, string complains)
        {
            FeedBack = feedBack;
            Rating = rating;
            Complains = complains;
            this.UserName = UserName;
        }
        public string GetFeedBack() 
        {
            return FeedBack;
        }
        public string GetUserName()
        {
            return UserName;
        }
        public string GetRating()
        {
            return Rating;
        }
        public string GetComplains()
        {
            return Complains;
        }
    }
}
