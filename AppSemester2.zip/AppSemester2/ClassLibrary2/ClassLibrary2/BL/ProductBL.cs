﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2.BL
{
    public class ProductBL
    {
        private string Name;
        private float Price;
        private int Quantity;
        private float Discount;
        private string Catagory;
        public ProductBL(string name, float price, int quantity, float discount, string catagory)
        {
            Name = name;
            Price = price;
            Quantity = quantity;
            Discount = discount;
            Catagory = catagory;
        }
        public string GetName()
        {
            return Name;
        }
        public float GetPrice()
        {
            return Price;
        }
        public int GetQuantity()
        {
            return Quantity;
        }
        public float GetDiscount()
        {
            return Discount;
        }
        public string GetCatagory()
        {
            return Catagory;
        }
    }
}
