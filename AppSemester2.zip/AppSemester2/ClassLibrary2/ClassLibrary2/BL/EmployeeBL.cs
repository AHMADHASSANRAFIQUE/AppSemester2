﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2.BL
{
    public class EmployeeBL : CrrendentialBL
    {
        private int Phone;

        public EmployeeBL(string name, string pass, string role, int phone) : base(name, pass, role)
        {
            this.Phone = phone;
        }

        public int GetPhone()
        {
            return this.Phone;
        }
    }
}
