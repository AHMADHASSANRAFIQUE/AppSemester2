﻿using ClassLibrary2.DL;
using ClassLibrary2.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class ObjectHandler
    {
        private static IUSER UserDB = new UserDL();
        //  private static IUSER UserFH = new UserFH(); // Assuming you have implemented UserFH class

        public static IUSER GetUserDB()
        {
            return UserDB;
        }
    }
}
